$(window).scroll(function (e) {
    $el = $('nav');
    var leadheight = $('#main').height();
    var navheight = $('nav').height();

    var windowWidth = $(this).width();

    if ($(this).scrollTop() < leadheight && $el.css('position') == 'fixed') {
            $('nav').css({ 'position':'relative'});
            $('#contentwrap').css({'margin-top':'0' , 'padding-top':'0'});
            $('#myname').css({'display':'inline-block'});
            $('#gototop').css({'display':'none'});
        }
        if ($(this).scrollTop() > leadheight && $el.css('position') != 'fixed') {
            $('nav').css({ 'position':'fixed' , 'top':'0'});
            $('#contentwrap').css({'margin-top':navheight , 'padding-top':navheight});
            if (windowWidth > 640) {
                $('#gototop').css({'float':'right' , 'display':'inline-block'});
            } else {
                $('#myname').css({'float':'none' , 'display':'none'});
                $('#gototop').css({'float':'right' , 'display':'inline-block'});
            }
        }

    $(window).resize(function(){
        var windowWidth = $(this).width();

        if (windowWidth > 640) {
            $('#gototop').css({'float':'right' , 'display':'inline-block'});
            $('#myname').css({'display':'inline-block'});
        } else {
            $('#myname').css({'float':'none' , 'display':'none'});
            $('#gototop').css({'float':'right' , 'display':'inline-block'});
        }
    });
});

$(function() {
  $('a[href*="#"]:not([href="#"])').click(function() {
    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
      if (target.length) {
        $('html, body').animate({
          scrollTop: target.offset().top
        }, 600);
        return false;
      }
    }
  });
});
